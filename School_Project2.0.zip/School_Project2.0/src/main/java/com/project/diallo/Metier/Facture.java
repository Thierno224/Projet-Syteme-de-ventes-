package com.project.diallo.Metier;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Facture implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idFacture ;
	private String libelle ;
	private Date date ;
	
	public Facture(String libelle, Date date) {
 
		this.libelle = libelle;
		this.date = date;
	}
	
	
	public Facture(int idFacture, String libelle, Date date) {
		super();
		this.idFacture = idFacture;
		this.libelle = libelle;
		this.date = date;
	}


	public int getIdFacture() {
		return idFacture;
	}


	public void setIdFacture(int idFacture) {
		this.idFacture = idFacture;
	}


	public String getLibelle() {
		return libelle;
	}


	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	@Override
	public String toString() {
		return "Facture [idFacture=" + idFacture + ", libelle=" + libelle + ", date=" + date + "]";
	}
	
	

}
