package com.project.diallo.web;
 

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.validation.Valid;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.project.diallo.DAO.EmployeRepository;
import com.project.diallo.Metier.Employe;


@Controller
 
public class EmployeController {
	
	@Autowired // pour l'injection de dependance  
	
	private EmployeRepository employeRepository ;
	
	@Value("${dir.images}")
	private String imageDir ;
	
	@RequestMapping(value="/admin")
	public String adminPage(Model model ) {
		
		return "adminPage" ;
	}
	
	@RequestMapping(value="/Employe")
    public String employe(Model model, @RequestParam(name="page", defaultValue="0")int p) {
		Page<Employe> pageEmploye = employeRepository.findAll(new PageRequest(p, 4));
        
		int pagesCourante = pageEmploye.getTotalPages();
		int[] pages = new int[pagesCourante];
		for(int i = 0 ; i< pagesCourante ; i++)
			pages[i] = i;
		model.addAttribute("pages", pages);
		model.addAttribute("pageEmployes", pageEmploye);
		model.addAttribute("pageCourante", p);
		return "employes" ;
	}
 
	
	@RequestMapping(value="/save", method=RequestMethod.GET)
	public String formEmploye(Model model) {
		model.addAttribute("employe", new Employe());
	
		return "empSave";
	}
	

	@RequestMapping(value="/saveEmploye", method=RequestMethod.POST)
	public String enregistrerEmploye(@Valid Employe emp, BindingResult bindingResult,
			@RequestParam(name="picture")MultipartFile file) throws Exception, IOException  {
		
		if(bindingResult.hasErrors()) {
			 
			return "empSave" ;
		}
		
		 if(!(file.isEmpty())) {
			 emp.setPhoto(file.getOriginalFilename());
			
		 }
		 employeRepository.save(emp);
		  if(!(file.isEmpty())) { 
			  emp.setPhoto(file.getOriginalFilename());
		      file.transferTo(new File(System.getProperty("user.home")+"/ProjetPhoto/"+emp.getIdEmploye())); 
		  }
 		  	    
		return "redirect:Employe";		
	}
	
	@RequestMapping(value="/getPhoto", produces=org.springframework.http.MediaType.IMAGE_PNG_VALUE)
	@ResponseBody
	public byte[] getPhoto(Long id) throws Exception, IOException {
		File f = new File(System.getProperty("user.home")+"/ProjetPhoto/"+id) ;
		 
		return IOUtils.toByteArray(new FileInputStream(f)) ;	
	}
	
	@RequestMapping(value = "/delete")
	public String delete (Long id) {
		employeRepository.deleteById(id) ;
		return "redirect:/Employe" ;
	}
	
	@RequestMapping(value = "/edit")
	public String edit (Long id, Model model) {
		Employe emp = employeRepository.getOne(id);
		model.addAttribute("employe", emp);
		return "empUpdate" ;
	}
	

	@RequestMapping(value="/updateEmploye", method=RequestMethod.POST)
	public String update(@Valid Employe emp, BindingResult bindingResult,
			@RequestParam(name="picture")MultipartFile file) throws Exception, IOException  {
		
		if(bindingResult.hasErrors()) {
			 
			return "empSave" ;
		}
		
		 if(!(file.isEmpty())) {
			 emp.setPhoto(file.getOriginalFilename());
			
		 }
		 employeRepository.save(emp);
		  if(!(file.isEmpty())) { 
			  emp.setPhoto(file.getOriginalFilename());
		      file.transferTo(new File(System.getProperty("user.home")+"/ProjetPhoto/"+emp.getIdEmploye())); 
		  }
		 
 	    
		return "redirect:Employe";		
	}

}
