package com.project.diallo.Metier;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

import org.springframework.format.annotation.DateTimeFormat;
 
 


@Entity
public class Employe implements Serializable{
 
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue
	private long idEmploye;
	@NotEmpty
 	private String nom ;
	@NotEmpty
  	private String prenom ;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateNaissance ;
    @NotEmpty
 	private String fonction ;
    @NotEmpty
 	private String adresse ;
    @Email
 	private String mail ;
 	private int telephone ;
 	
	private String photo ;
	
	
	public Employe() {
		super();
	}


	public Employe(String nom, String prenom, Date dateNaissance, String fonction, String adresse,
			String mail, int telephone, String photo) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateNaissance;
		this.fonction = fonction;
		this.adresse = adresse;
		this.mail = mail;
		this.telephone = telephone;
		this.photo = photo;
	}


	public Employe(long idEmploye, String nom, String prenom, Date dateNaissance, String fonction,
			String adresse, String mail, int telephone, String photo) {
		super();
		this.idEmploye = idEmploye;
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateNaissance;
 
		this.fonction = fonction;
		this.adresse = adresse;
		this.mail = mail;
		this.telephone = telephone;
		this.photo = photo;
	}


	public long getIdEmploye() {
		return idEmploye;
	}


	public void setIdEmploye(long idEmploye) {
		this.idEmploye = idEmploye;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}


	public Date getDateNaissance() {
		return dateNaissance;
	}


	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
 
	public String getFonction() {
		return fonction;
	}


	public void setFonction(String fonction) {
		this.fonction = fonction;
	}


	public String getAdresse() {
		return adresse;
	}


	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}


	public String getMail() {
		return mail;
	}


	public void setMail(String mail) {
		this.mail = mail;
	}


	public int getTelephone() {
		return telephone;
	}


	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}


	public String getPhoto() {
		return photo;
	}


	public void setPhoto(String photo) {
		this.photo = photo;
	}


	@Override
	public String toString() {
		return "Employe [idEmploye=" + idEmploye + ", nom=" + nom + ", prenom=" + prenom + ", dateNaissance="
				+ dateNaissance + ", fonction=" + fonction + ", adresse=" + adresse
				+ ", mail=" + mail + ", telephone=" + telephone + ", photo=" + photo + "]";
	}
	   
	
}
