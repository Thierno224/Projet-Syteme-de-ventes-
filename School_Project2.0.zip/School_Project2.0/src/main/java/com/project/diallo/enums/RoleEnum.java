package com.project.diallo.enums;

public enum RoleEnum {
	
	USER,
	ADMINISTRATOR

}
