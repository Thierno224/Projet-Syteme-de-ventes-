package com.project.diallo.DAO;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.diallo.Metier.Options;

public interface OptionsRepository extends JpaRepository<Options, Long>{
	
 
	
	@Query("select o from Options o where o.airBag like :x")
	public Page<Options> chercheParMotCle(@Param("x")String mc, Pageable pageable);
	
	

}
