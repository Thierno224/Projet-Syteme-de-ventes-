package com.project.diallo.Metier;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Societe implements Serializable{ 
 
	private static final long serialVersionUID = 1L;
	@Id @GeneratedValue
	private int idSociete ;
	private String nomSocite ;
	private String adresse;
	private String ville ;
	private String pays ;
	private int telephone ;
	
	public Societe(String nomSocite, String adresse, String ville, String pays, int telephone) {
		 
 		this.nomSocite = nomSocite;
		this.adresse = adresse;
		this.ville = ville;
		this.pays = pays;
		this.telephone = telephone;
	}
	
	public Societe(int idSociete, String nomSocite, String adresse, String ville, String pays, int telephone) {
		
		super();
		this.idSociete = idSociete;
		this.nomSocite = nomSocite;
		this.adresse = adresse;
		this.ville = ville;
		this.pays = pays;
		this.telephone = telephone;
	}

	public int getIdSociete() {
		return idSociete;
	}

	public void setIdSociete(int idSociete) {
		this.idSociete = idSociete;
	}

	public String getNomSocite() {
		return nomSocite;
	}

	public void setNomSocite(String nomSocite) {
		this.nomSocite = nomSocite;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getPays() {
		return pays;
	}

	public void setPays(String pays) {
		this.pays = pays;
	}

	public int getTelephone() {
		return telephone;
	}

	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}

	@Override
	public String toString() {
		return "Societe [idSociete=" + idSociete + ", nomSocite=" + nomSocite + ", adresse=" + adresse + ", ville="
				+ ville + ", pays=" + pays + ", telephone=" + telephone + "]";
	}
	
	

}
