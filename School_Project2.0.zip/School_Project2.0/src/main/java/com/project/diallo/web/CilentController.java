package com.project.diallo.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.validation.Valid;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.project.diallo.DAO.ClientRepository;
import com.project.diallo.Metier.Client;
 
 

@Controller
public class CilentController {
	
	@Autowired
	private ClientRepository clientRepository ;
	
	
	@RequestMapping(value="/client" , method=RequestMethod.GET)
    public String client(Model model, @RequestParam(name="page", defaultValue="0")int p) {
		Page<Client> pageClient = clientRepository.findAll(new PageRequest(p, 4));
        
		int pagesCount = pageClient.getTotalPages();
		int[] pages = new int[pagesCount];
		for(int i = 0 ; i< pagesCount ; i++)
			pages[i] = i;
		model.addAttribute("pages", pages);
		model.addAttribute("pageClients", pageClient);
		model.addAttribute("pageCourante",p);
		return "clients" ;
	}
	
	@RequestMapping(value="/client/form", method=RequestMethod.GET)
	public String save(Model model) {
		model.addAttribute("client", new Client());
		return "saveClient" ;
	}
	
	@RequestMapping(value="/client/delete", method=RequestMethod.GET)
	public String delete(Long id) {
		clientRepository.deleteById(id);
		return "redirect:/client" ;
	}
	
	@RequestMapping(value = "/edite")
	public String editer(Long id, Model model) {
		Client clt = clientRepository.getOne(id);
		model.addAttribute("client", clt);
		return "updateClient" ;
	}
	
	@RequestMapping(value="/saveClient", method=RequestMethod.POST)
	public String enregistrerClient(@Valid Client clt, BindingResult bindingResult,
			@RequestParam(name="picture")MultipartFile file) throws Exception, IOException  {
		
		if(bindingResult.hasErrors()) {
			 
			return "saveClient" ;
		}
		
		 if(!(file.isEmpty())) {
			 clt.setPhoto(file.getOriginalFilename());
			
		 }
		 clientRepository.save(clt);
		  if(!(file.isEmpty())) { 
			  clt.setPhoto(file.getOriginalFilename());
		      file.transferTo(new File(System.getProperty("user.home")+"/ProjetPhoto/"+clt.getIdClient())); 
		  }
 		  	    
		return "redirect:/client";		
	}
	@RequestMapping(value="/voirPhoto", produces=org.springframework.http.MediaType.IMAGE_PNG_VALUE)
	@ResponseBody
	public byte[] voirPhoto(Long id) throws Exception, IOException {
		File f = new File(System.getProperty("user.home")+"/ProjetPhoto/"+id) ;
		 
		return IOUtils.toByteArray(new FileInputStream(f)) ;	
	}
	
	@RequestMapping(value="/client/update",  method =  RequestMethod.POST)
	public String update(@Valid Client clt, BindingResult bindingResult,
			@RequestParam(name="picture")MultipartFile file) throws Exception, IOException  {
		
		if(bindingResult.hasErrors()) {
			 
			return "updateClient" ;
		}
		
		 if(!(file.isEmpty())) {
			 clt.setPhoto(file.getOriginalFilename());
			
		 }
		 clientRepository.save(clt);
		  if(!(file.isEmpty())) { 
			  clt.setPhoto(file.getOriginalFilename());
		      file.transferTo(new File(System.getProperty("user.home")+"/ProjetPhoto/"+clt.getIdClient())); 
		  }
		 
 	    
		return "redirect:/client";		
	}

}
