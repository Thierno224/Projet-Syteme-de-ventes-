package com.project.diallo.Metier;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Rapport  implements Serializable{
 
	private static final long serialVersionUID = 1L;
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private  Long id ;
	private String nomEmp;
	private String prenomEmp;
	private String nomClt;
	private String prenomClt;
	private int telephone ;
	private String adresse;
	private String mail;
	private int nbVisite;
	private Date dateVisite;
	private String typeCommande;
	private String message ;
	
	
	public Rapport() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Rapport(String nomEmp, String prenomEmp, String nomClt, String prenomClt, int telephone, String adresse,
			String mail, int nbVisite, Date dateVisite, String typeCommande, String message) {
		super();
		this.nomEmp = nomEmp;
		this.prenomEmp = prenomEmp;
		this.nomClt = nomClt;
		this.prenomClt = prenomClt;
		this.telephone = telephone;
		this.adresse = adresse;
		this.mail = mail;
		this.nbVisite = nbVisite;
		this.dateVisite = dateVisite;
		this.typeCommande = typeCommande;
		this.message = message ; 
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNomEmp() {
		return nomEmp;
	}


	public void setNomEmp(String nomEmp) {
		this.nomEmp = nomEmp;
	}


	public String getPrenomEmp() {
		return prenomEmp;
	}


	public void setPrenomEmp(String prenomEmp) {
		this.prenomEmp = prenomEmp;
	}


	public String getNomClt() {
		return nomClt;
	}


	public void setNomClt(String nomClt) {
		this.nomClt = nomClt;
	}


	public String getPrenomClt() {
		return prenomClt;
	}


	public void setPrenomClt(String prenomClt) {
		this.prenomClt = prenomClt;
	}


	public int getTelephone() {
		return telephone;
	}


	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}


	public String getAdresse() {
		return adresse;
	}


	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}


	public String getMail() {
		return mail;
	}


	public void setMail(String mail) {
		this.mail = mail;
	}


	public int getNbVisite() {
		return nbVisite;
	}


	public void setNbVisite(int nbVisite) {
		this.nbVisite = nbVisite;
	}


	public Date getDateVisite() {
		return dateVisite;
	}


	public void setDateVisite(Date dateVisite) {
		this.dateVisite = dateVisite;
	}


	public String getTypeCommande() {
		return typeCommande;
	}


	public void setTypeCommande(String typeCommande) {
		this.typeCommande = typeCommande;
	}
	

	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}
	
	
	


	@Override
	public String toString() {
		return "Rapport [nomEmp=" + nomEmp + ", prenomEmp=" + prenomEmp + ", nomClt=" + nomClt + ", prenomClt="
				+ prenomClt + ", telephone=" + telephone + ", adresse=" + adresse + ", mail=" + mail + ", nbVisite="
				+ nbVisite + ", dateVisite=" + dateVisite + ", typeCommande=" + typeCommande + "]";
	}



}
