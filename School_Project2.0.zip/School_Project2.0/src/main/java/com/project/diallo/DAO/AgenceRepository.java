package com.project.diallo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.diallo.Metier.Agence;

public interface AgenceRepository extends JpaRepository<Agence, Long>{

}
