package com.project.diallo.web;
 
public class LoginController {
 
}