package com.project.diallo.DAO;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.diallo.Metier.Vehicule;

public interface VehiculeRepository extends JpaRepository<Vehicule, Long>{
	
	public List<Vehicule> findByMarque(String n) ;
	public Page<Vehicule> findByMarque(String n, Pageable pageable);	
	
	@Query("select v from Vehicule v where v.marque like :x")
	public Page<Vehicule> chercheParMotCle(@Param("x")String mc, Pageable pageable);	

}
