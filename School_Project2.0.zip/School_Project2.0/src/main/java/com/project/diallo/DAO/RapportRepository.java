package com.project.diallo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.diallo.Metier.Rapport;

public interface RapportRepository extends JpaRepository<Rapport, Long>{

}
