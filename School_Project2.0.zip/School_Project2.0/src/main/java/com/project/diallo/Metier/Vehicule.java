package com.project.diallo.Metier;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

  
@Entity
public class Vehicule implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private Long idVehicule ;
	private String nom ;
	private String marque ;
	private String Modele ;
	private String constructeur;
 	private String annee;
  	private double prix ;
  	private String photo ;
  		
	public Vehicule() {
		super();
	}



	public Vehicule(String nom, String marque, String modele, String constructeur, String annee, double prix,
			String photo) {
		super();
		this.nom = nom;
		this.marque = marque;
		Modele = modele;
		this.constructeur = constructeur;
		this.annee = annee;
		this.prix = prix;
		this.photo = photo;
	}



	public Vehicule(Long idVehicule, String nom, String marque, String modele, String constructeur, String annee,
			double prix, String photo) {
		super();
		this.idVehicule = idVehicule;
		this.nom = nom;
		this.marque = marque;
		Modele = modele;
		this.constructeur = constructeur;
		this.annee = annee;
		this.prix = prix;
		this.photo = photo;
	}



	public Long getIdVehicule() {
		return idVehicule;
	}



	public void setIdVehicule(Long idVehicule) {
		this.idVehicule = idVehicule;
	}



	public String getNom() {
		return nom;
	}



	public void setNom(String nom) {
		this.nom = nom;
	}



	public String getMarque() {
		return marque;
	}



	public void setMarque(String marque) {
		this.marque = marque;
	}



	public String getModele() {
		return Modele;
	}



	public void setModele(String modele) {
		Modele = modele;
	}



	public String getConstructeur() {
		return constructeur;
	}



	public void setConstructeur(String constructeur) {
		this.constructeur = constructeur;
	}



	public String getAnnee() {
		return annee;
	}



	public void setAnnee(String annee) {
		this.annee = annee;
	}



	public double getPrix() {
		return prix;
	}



	public void setPrix(double prix) {
		this.prix = prix;
	}



	public String getPhoto() {
		return photo;
	}



	public void setPhoto(String photo) {
		this.photo = photo;
	}



	@Override
	public String toString() {
		return "Vehicule [idVehicule=" + idVehicule + ", nom=" + nom + ", marque=" + marque + ", Modele=" + Modele
				+ ", constructeur=" + constructeur + ", annee=" + annee + ", prix=" + prix + ", photo=" + photo + "]";
	}
	
	
 
	
}
