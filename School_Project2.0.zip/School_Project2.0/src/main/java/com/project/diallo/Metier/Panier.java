package com.project.diallo.Metier;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
 

@Entity
public class Panier implements Serializable{

	private static final long serialVersionUID = 1L;
	
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)	
	private Long idPanier ;
	private String libelle ;
	private int quantite ;
	private double prixUnitaire ;

	private String photo ;
	
    
    public Panier() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Panier(String libelle, int quantite, double prixUnitaire, String photo) {
		super();
		this.libelle = libelle;
		this.quantite = quantite;
		this.prixUnitaire = prixUnitaire;
		this.photo = photo;
	}


	public Panier(String libelle, int quantite, double prixUnitaire) {
		super();
		this.libelle = libelle;
		this.quantite = quantite;
		this.prixUnitaire = prixUnitaire;
	}

 
	public Long getIdPanier() {
		return idPanier;
	}


	public void setIdPanier(Long idPanier) {
		this.idPanier = idPanier;
	}


	public String getLibelle() {
		return libelle;
	}


	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}


	public int getQuantite() {
		return quantite;
	}


	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}


	public double getPrixUnitaire() {
		return prixUnitaire;
	}


	public void setPrixUnitaire(double prixUnitaire) {
		this.prixUnitaire = prixUnitaire;
	}


	public String getPhoto() {
		return photo;
	}


	public void setPhoto(String photo) {
		this.photo = photo;
	}


 
	/*
	private Map<Long, LigneCommande> items = new HashMap<Long, LigneCommande>();
	
	public void ajouterVehicule(Vehicule v , int quantite) {
		
		if(items.get(v.getIdVehicule()) == null) {
			LigneCommande lc = new LigneCommande();
			lc.setVehicule(v);
			lc.setQuantite(quantite);
			lc.setPrix(v.getPrix());
		}
		
		else {
			LigneCommande lc = items.get(v.getIdVehicule());
			lc.setQuantite(quantite);
			lc.setPrix(v.getPrix());
		}
	}
	
	//  Methode pour retourner l'esemble de vehicule dans le panier
	
	public Collection<LigneCommande> getItems(){
		return items.values();
	}
	
	// Total du panier
	
	public double getTotalPanier() {
		double total = 0 ; 
		for(LigneCommande lc : items.values()) {
			total = total + lc.getPrix()*lc.getQuantite();
		}
		return total ;
	}
	
	public int nobreVehicule() {
		return items.size();
	}
	
	public void supprimerItems(Long idVehicule) {
		items.remove(idVehicule);
	}
*/
}
