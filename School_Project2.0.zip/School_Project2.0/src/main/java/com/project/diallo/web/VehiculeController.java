package com.project.diallo.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.validation.Valid;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.project.diallo.DAO.VehiculeRepository;
import com.project.diallo.Metier.Vehicule;

@Controller
public class VehiculeController {

	@Autowired
	private VehiculeRepository vehiculeRepository;

	@RequestMapping(value = "/Vehicule")
	public String vehicule(Model model, @RequestParam(name = "page", defaultValue = "0") int p) {
		Page<Vehicule> pageVehicule = vehiculeRepository.findAll(new PageRequest(p, 4));

		int pagesCourante = pageVehicule.getTotalPages();
		int[] pages = new int[pagesCourante];
		for (int i = 0; i < pagesCourante; i++)
			pages[i] = i;
		model.addAttribute("pages", pages);
		model.addAttribute("pageVehicules", pageVehicule);
		model.addAttribute("pageCourante", p);
		return "vehicules";
	}

	@RequestMapping(value = "/saveVehicule", method = RequestMethod.GET)
	public String formVehicule(Model model) {
		model.addAttribute("vehicule", new Vehicule());

		return "saveVehicule";
	}

	@RequestMapping(value = "/saveVehicule", method = RequestMethod.POST)
	public String enregistrerVehicule(@Valid Vehicule vehicule, BindingResult bindingResult,
			@RequestParam(name = "picture") MultipartFile file) throws Exception, IOException {

		if (bindingResult.hasErrors()) {

			return "saveVehicule";
		}

		if (!(file.isEmpty())) {
			vehicule.setPhoto(file.getOriginalFilename());

		}
		vehiculeRepository.save(vehicule);
		if (!(file.isEmpty())) {
			vehicule.setPhoto(file.getOriginalFilename());
			file.transferTo(new File(System.getProperty("user.home") + "/ProjetPhoto/" + vehicule.getIdVehicule()));
		}

		return "redirect:Vehicule";
	}

	@RequestMapping(value = "/getImage", produces = org.springframework.http.MediaType.IMAGE_PNG_VALUE)
	@ResponseBody
	public byte[] getImage(Long id) throws Exception, IOException {
		File f = new File(System.getProperty("user.home") + "/ProjetPhoto/" + id);

		return IOUtils.toByteArray(new FileInputStream(f));
	}

	@RequestMapping(value = "/deleteVehicule")
	public String delete(Long id) {
		vehiculeRepository.deleteById(id);
		return "redirect:/Vehicule";
	}

	@RequestMapping(value = "/updateVehicule", method = RequestMethod.POST)
	public String update(@Valid Vehicule vehicule, BindingResult bindingResult,
			@RequestParam(name = "picture") MultipartFile file) throws Exception, IOException {

		if (bindingResult.hasErrors()) {

			return "updateVehicule";
		}

		if (!(file.isEmpty())) {
			vehicule.setPhoto(file.getOriginalFilename());

		}
		vehiculeRepository.save(vehicule);
		if (!(file.isEmpty())) {
			vehicule.setPhoto(file.getOriginalFilename());
			file.transferTo(new File(System.getProperty("user.home") + "/ProjetPhoto/" + vehicule.getIdVehicule()));
		}

		return "redirect:Vehicule";
	}	
	  
	  @RequestMapping(value = "/editeVehicule")
      public String edit (Long id, Model model) { 
		  Vehicule v = vehiculeRepository.getOne(id);
	      model.addAttribute("vehicule", v); 
	  
	  return "updateVehicule" ; 
	  }

}
