package com.project.diallo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.diallo.Metier.Role;

public interface RoleRepository extends JpaRepository<Role, Long>{

	Role findByRole(String role);

}
