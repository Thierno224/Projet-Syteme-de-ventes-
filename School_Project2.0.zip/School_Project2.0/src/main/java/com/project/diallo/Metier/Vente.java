package com.project.diallo.Metier;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Vente implements Serializable{
 
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idVente ;
	private String libelle ;
	private Date date ;
	
	public Vente(String libelle, Date date) {
 
		this.libelle = libelle;
		this.date = date;
	}
	
	public Vente(int idVente, String libelle, Date date) {
		super();
		this.idVente = idVente;
		this.libelle = libelle;
		this.date = date;
	}

	public int getIdVente() {
		return idVente;
	}

	public void setIdVente(int idVente) {
		this.idVente = idVente;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Vente [idVente=" + idVente + ", libelle=" + libelle + ", date=" + date + "]";
	}
	
	

}
