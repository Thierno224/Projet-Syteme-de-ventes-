package com.project.diallo.DAO;

 
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.diallo.Metier.Client;
 
public interface ClientRepository extends JpaRepository<Client, Long>{
	
	
	public List<Client> findByNom(String n);
	public Page<Client> findByNom(String n, Pageable pageable);	
	
	@Query("select c from Client c where c.nom like :x")
	public Page<Client> chercheParMotCle(@Param("x")String mc, Pageable pageable);
 
}
