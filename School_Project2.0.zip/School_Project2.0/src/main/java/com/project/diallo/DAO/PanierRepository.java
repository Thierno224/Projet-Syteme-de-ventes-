package com.project.diallo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.diallo.Metier.Panier;
import com.project.diallo.Metier.Vehicule;

public interface PanierRepository extends JpaRepository<Panier, Long>{

	 

}
