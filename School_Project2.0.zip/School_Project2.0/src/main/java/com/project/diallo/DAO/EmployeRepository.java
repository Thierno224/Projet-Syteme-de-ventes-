package com.project.diallo.DAO;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.diallo.Metier.Employe;

public interface EmployeRepository extends JpaRepository<Employe, Long>{
	
	public List<Employe> findByNom(String n);
	public Page<Employe> findByNom(String n, Pageable pageable);	
	
	@Query("select e from Employe e where e.nom like :x")
	public Page<Employe> chercheParMotCle(@Param("x")String mc, Pageable pageable);
 
	@Query("select e from Employe e where e.dateNaissance>:x and e.dateNaissance<:y")
	public List<Employe> chercheParDateNaiss(@Param("x")Date d1, @Param("y")Date d2);
}
