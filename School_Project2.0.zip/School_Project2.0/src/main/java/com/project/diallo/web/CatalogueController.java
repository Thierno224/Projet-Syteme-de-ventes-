package com.project.diallo.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.diallo.DAO.VehiculeRepository;
import com.project.diallo.Metier.Vehicule;

@Controller
public class CatalogueController {
	

	@Autowired
	private VehiculeRepository vehiculeRepository;

	@RequestMapping(value = "/catalogue")
	public String CatalogueVehicule(Model model, @RequestParam(name = "page", defaultValue = "0") int p) {
		Page<Vehicule> pageVehicule = vehiculeRepository.findAll(new PageRequest(p, 2));

		int pagesCourante = pageVehicule.getTotalPages();
		int[] pages = new int[pagesCourante];
		for (int i = 0; i < pagesCourante; i++)
			pages[i] = i;
		model.addAttribute("pages", pages);
		model.addAttribute("pageVehicules", pageVehicule);
		model.addAttribute("pageCourante", p);
		return "catlgClient";
	}
	
	@RequestMapping(value = "/voirImage", produces = org.springframework.http.MediaType.IMAGE_PNG_VALUE)
	@ResponseBody
	public byte[] voirImage(Long id) throws Exception, IOException {
		File f = new File(System.getProperty("user.home") + "/ProjetPhoto/" + id);

		return IOUtils.toByteArray(new FileInputStream(f));
	}


}
