package com.project.diallo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.diallo.Metier.LigneCommande;
import com.project.diallo.Metier.Vehicule;

public interface LigneCommandeRepository extends JpaRepository<LigneCommande, Long>{

	 

	 

}
