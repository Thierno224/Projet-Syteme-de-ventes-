package com.project.diallo.controller;

 
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
 
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
 
import com.project.diallo.Metier.Vehicule;

 
@Controller
public class HomePageController {
	
 
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
    public String home(Model model) {
		model.addAttribute("page", new Vehicule());
    	return "home";
    }
 
}
