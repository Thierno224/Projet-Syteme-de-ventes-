package com.project.diallo.Metier;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Options implements Serializable{
 
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long idOption ;
	private String climatisation ;
    private String airBag ;
    private int nbrePlace ; 
    private int nbrePorte ;
    private String typeCarburant ;
	
    
    
    public Options() {
		super();
	}



	public Options(String climatisation, String airBag, int nbrePlace, int nbrePorte, String typeCarburant) {
		super();
		this.climatisation = climatisation;
		this.airBag = airBag;
		this.nbrePlace = nbrePlace;
		this.nbrePorte = nbrePorte;
		this.typeCarburant = typeCarburant;
	}



	public Options(long idOption, String climatisation, String airBag, int nbrePlace, int nbrePorte,
			String typeCarburant) {
		super();
		this.idOption = idOption;
		this.climatisation = climatisation;
		this.airBag = airBag;
		this.nbrePlace = nbrePlace;
		this.nbrePorte = nbrePorte;
		this.typeCarburant = typeCarburant;
	}



	public long getIdOption() {
		return idOption;
	}



	public void setIdOption(long idOption) {
		this.idOption = idOption;
	}



	public String getClimatisation() {
		return climatisation;
	}



	public void setClimatisation(String climatisation) {
		this.climatisation = climatisation;
	}



	public String getAirBag() {
		return airBag;
	}



	public void setAirBag(String airBag) {
		this.airBag = airBag;
	}



	public int getNbrePlace() {
		return nbrePlace;
	}



	public void setNbrePlace(int nbrePlace) {
		this.nbrePlace = nbrePlace;
	}



	public int getNbrePorte() {
		return nbrePorte;
	}



	public void setNbrePorte(int nbrePorte) {
		this.nbrePorte = nbrePorte;
	}



	public String getTypeCarburant() {
		return typeCarburant;
	}



	public void setTypeCarburant(String typeCarburant) {
		this.typeCarburant = typeCarburant;
	}



	@Override
	public String toString() {
		return "Options [idOption=" + idOption + ", climatisation=" + climatisation + ", airBag=" + airBag
				+ ", nbrePlace=" + nbrePlace + ", nbrePorte=" + nbrePorte + ", typeCarburant=" + typeCarburant + "]";
	}

 
    
}
