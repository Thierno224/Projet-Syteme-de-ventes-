package com.project.diallo.web;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

 
import com.project.diallo.DAO.RapportRepository;
import com.project.diallo.Metier.Rapport;
 

@Controller
public class RapportController {
	
	@Autowired
	RapportRepository rapportRepository ;
	
	@RequestMapping(value = "/rapport", method = RequestMethod.GET)
    public String getRapport(Model model) {
		model.addAttribute("rapport", new Rapport());
    	return "rapport";
    }
 
	@RequestMapping(value = "/saveRapport", method = RequestMethod.POST)
    public String saveRapport(@Valid Rapport rapport, BindingResult bindingResult) {
		if(bindingResult.hasErrors())
		   return "rapport";
		rapportRepository.save(rapport);
    	return "admin";
    }
	


}
