package com.project.diallo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.diallo.Metier.Visite;

public interface VisiteRepository extends JpaRepository<Visite, Long>{

}
