package com.project.diallo;

 
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import com.project.diallo.DAO.ClientRepository;
 
import com.project.diallo.DAO.EmployeRepository;
import com.project.diallo.DAO.LigneCommandeRepository;
import com.project.diallo.DAO.OptionsRepository;
import com.project.diallo.DAO.PanierRepository;
import com.project.diallo.DAO.RapportRepository;
import com.project.diallo.DAO.RoleRepository;
import com.project.diallo.DAO.UserRepository;
import com.project.diallo.DAO.VehiculeRepository;
import com.project.diallo.Metier.Client;
 
import com.project.diallo.Metier.Employe;
import com.project.diallo.Metier.LigneCommande;
import com.project.diallo.Metier.Options;
import com.project.diallo.Metier.Panier;
import com.project.diallo.Metier.Role;
import com.project.diallo.Metier.User;
import com.project.diallo.Metier.Vehicule;
  

@SpringBootApplication
public class Application {

	public static void main(String[] args) throws ParseException {
		
		ApplicationContext ctx = SpringApplication.run(Application.class, args);
		EmployeRepository employeRepository = ctx.getBean(EmployeRepository.class);
		ClientRepository clientRepository   = ctx.getBean(ClientRepository.class);
		OptionsRepository optionsRepository = ctx.getBean(OptionsRepository.class);
		VehiculeRepository vehiculeRepository = ctx.getBean(VehiculeRepository.class);
	//	CommandeRepository commandeRepository = ctx.getBean(CommandeRepository.class);
		LigneCommandeRepository ligneCommandeRepository = ctx.getBean(LigneCommandeRepository.class);
		PanierRepository panierRepository = ctx.getBean(PanierRepository.class);
		UserRepository userRepository = ctx.getBean(UserRepository.class);
		RoleRepository roleRepository = ctx.getBean(RoleRepository.class);
		RapportRepository rapportRepository = ctx.getBean(RapportRepository.class);
		
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		Map<Long, Vehicule> items = new HashMap<Long, Vehicule>();
		
		
		
		
		/*
		employeRepository.save(
		new Employe("DIALLO", "Thierno Souleymane", df.parse("1993-01-05"), "Paris", "Directeur", 
				    "64 rue vitry 94400", "thierno@gmail.com", 783058507, "th.jpg"));
		
		employeRepository.save(
	    new Employe("BARRY", "Mamadou bobo", df.parse("1983-01-05"), "Paris 13e Arrondissement ", "Directeur", 
			        "64 rue Paris 75013", "mamadou@gmail.com", 783058222, "bobo.jpg"));
		
		employeRepository.save(
			    new Employe("BAH", "Amina", df.parse("1999-05-15"), "Bretagne ", "Directrice", 
					        "64 rue vitry 94400", "amina.bah@gmail.com", 643058507, "amina.jpg"));
		
		employeRepository.save(
			    new Employe("DIALLO", "Mariam Kesso", df.parse("1994-09-25"), "Bretagne ", "Responsemble commercial", 
					        "64 rue LIlle 49000", "kesso.riam@gmail.com", 643058507, "kesso.jpg"));
		*/
		
		Page<Employe> emp = employeRepository.findAll(new PageRequest(0, 3));
		
		System.out.println("\n---------------------------------------- Recherche Employer ----------------------------------------------\n");

		emp.forEach(e->System.out.println("Nom emloyer : "+e.getNom()+" | "+ " Prenom employer : "+e.getPrenom()+" | "
		                                  +" Date naissance : "+e.getDateNaissance()));		
		
		Page<Employe> empMc = employeRepository.chercheParMotCle("%l%", new PageRequest(0, 3));
		
		System.out.println("\n---------------------------------------- Recherche Par mot cle ----------------------------------------------\n");
		
		empMc.forEach(e->System.out.println("Nom emloyer : "+e.getNom()+" | "+ " Prenom employer : "+e.getPrenom()+" | "
                +" Date naissance : "+e.getDateNaissance()));
		
		System.out.println("\n---------------------------------------- Gestion Client ----------------------------------------------\n");
		
		/*
		 * clientRepository.save(new Client("Barry" , "Mamadou", "75013 Paris",
		 * "barry@gmail.com", 124578, "img.jpg")) ; clientRepository.save(new
		 * Client("Jean Marc" , "Dupond", "75010 Paris", "dupond@gmail.com", 124578,
		 * "img.jpg")) ; clientRepository.save(new Client("Durend" , "Dupond",
		 * "75003 Paris", "durand@gmail.com", 124578, "img.jpg")) ;
		 * clientRepository.save(new Client("Kante" , "Alpha", "75013 Paris",
		 * "balde@gmail.com", 124578, "img.jpg")) ;
		 */
		Page<Client> clients = clientRepository.findAll(new PageRequest(0, 3));
		
		System.out.println("\n---------------------------------------- Recherche les Clients ----------------------------------------------\n");

		clients.forEach(c -> System.out.println("Nom Client : "+c.getNom()+" | "+"Prenom Client "+c.getPrenom()));
		
		
		System.out.println("\n---------------------------------------- Gestion des Options ----------------------------------------------\n");
		/*
		 * 
		 * optionsRepository.save(new Options("Vehicule climatisé", "AirBag heitech", 5,
		 * 5, "Essence")); optionsRepository.save(new Options("Vehicule non climatisé",
		 * "AirBag heitech", 5, 5, "Diesel")); optionsRepository.save(new
		 * Options("Vehicule climatisé", "AirBag-360", 5, 5, "Essence"));
		 * optionsRepository.save(new Options("Vehicule climatisé",
		 * "AirBag double protèse", 5, 5, "Essence")); optionsRepository.save(new
		 * Options("Vehicule climatisé", "AirBag ultra moderne", 5, 5, "Diesel"));
		 */
		
		Page<Options> op = optionsRepository.findAll(new PageRequest(0, 4));
		
		op.forEach(o -> System.out.println("Nom Option : "+o.toString()));
		
		System.out.println("\n---------------------------------------- Gestion des Vehicules ----------------------------------------------\n");
		/*
		 * vehiculeRepository.save(new Vehicule("BMW-360", "Allemand", "Dernier modèle",
		 * "BMW Compagny", "2018", 65000.99, "img")); vehiculeRepository.save(new
		 * Vehicule("Mercedes", "Allemand", "Dernier modèle", "Mercedes Compagny",
		 * "2016", 75000.99, "img")); vehiculeRepository.save(new Vehicule("Audi",
		 * "Allemand", "Sport", "Audi Compagny", "2015", 35000.99, "img1"));
		 * vehiculeRepository.save(new Vehicule("Renault", "Français", "New génération",
		 * "Renault Compagny", "2010", 35000.99, "img1")); vehiculeRepository.save(new
		 * Vehicule("Citroen", "Français", "Dernier modèle", "BMW Compagny", "2018",
		 * 65000.99, "img1"));
		 */
        Page<Vehicule> vehicule = vehiculeRepository.findAll(new PageRequest(0, 4));
		
        vehicule.forEach(v -> System.out.println(v.toString()));
//        
//       Role userRole = roleRepository.findByRole("ADMIN");
//                    
//         User user = new User();
//         
//         user.setUser_id((long) 1);
//         user.setUsername("User");
//         user.setPassword("admin");tables 
//         user.setEmail("thiernosd25@gmail.com");
//         user.setRoles(new HashSet<Role>(Arrays.asList(userRole)));
//         userRepository.save(user);
//          
//         
//
//           
//        
            
 
         
         
        
		/*
		 * Commande cmd = new Commande(); Vehicule voiture = new Vehicule("BMW-360",
		 * "Allemand", "Dernier modèle","BMW Compagny", "2018", 65000.99, "img"); Client
		 * client = new Client("Barry" , "Mamadou", "75013 Paris","barry@gmail.com",
		 * 124578, "img.jpg") ;
		 */  
		
        /*
		 * cmd.setLibelle("Commande BMW"); cmd.setDateCommande(df.parse("2019-01-25"));
		 * 
		 * cmd.setCleint(client) ; cmd.setVehicule(voiture);
		 * commandeRepository.save(cmd);
		 * 
		 * Page <Commande> commande = commandeRepository.findAll(new PageRequest(0, 4));
		 * 
		 * commande.forEach(v -> System.out.println(v.toString()));
		 */
        
         
        
		/*
		 * 
		 * Vehicule v, v1, v2,v3 = new Vehicule () ;
		 * 
		 * 
		 * 
		 * Client clt = new Client () ; Commande com = new Commande() ;
		 * 
		 * clt = clientRepository.getOne((long) 16); v =
		 * vehiculeRepository.getOne((long) 245); v1 = vehiculeRepository.getOne((long)
		 * 245); v2 = vehiculeRepository.getOne((long) 245); v2 =
		 * vehiculeRepository.getOne((long) 245);
		 * 
		 * 
		 * LigneCommande lc = new LigneCommande() ; LigneCommande lc1 = new
		 * LigneCommande() ; LigneCommande lc2 = new LigneCommande() ;
		 * 
		 * 
		 * lc.setVehicule(v); lc.setQuantite(1); lc.setPrix(65000);
		 * ligneCommandeRepository.save(lc);
		 * 
		 * lc1.setVehicule(v1); lc1.setQuantite(1); lc1.setPrix(25000);
		 * ligneCommandeRepository.save(lc1);
		 * 
		 * Collection<LigneCommande> items = null ;
		 * System.out.println(lc.getPrix()+" | "+lc1.getPrix()+" | "+lc2.getPrix());
		 * 
		 * 
		 * 
		 * com.setDateCommande(df.parse("2019-05-15")); // com.setItems(items);
		 * com.setClient(clt); commandeRepository.save(com);
		 * 
		 */
          
		    
	}
}

