package com.project.diallo.Metier;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Agence implements Serializable{
 
	private static final long serialVersionUID = 1L;
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idAgence ;
	private String nomAgence ;
	private String departement ;
	private String responsable ;
	
	public Agence(String nomAgence, String departement, String responsable) {
 
		this.nomAgence = nomAgence;
		this.departement = departement;
		this.responsable = responsable;
	}
	
	
	public Agence(int idAgence, String nomAgence, String departement, String responsable) {
		super();
		this.idAgence = idAgence;
		this.nomAgence = nomAgence;
		this.departement = departement;
		this.responsable = responsable;
	}


	public int getIdAgence() {
		return idAgence;
	}


	public void setIdAgence(int idAgence) {
		this.idAgence = idAgence;
	}


	public String getNomAgence() {
		return nomAgence;
	}


	public void setNomAgence(String nomAgence) {
		this.nomAgence = nomAgence;
	}


	public String getDepartement() {
		return departement;
	}


	public void setDepartement(String departement) {
		this.departement = departement;
	}


	public String getResponsable() {
		return responsable;
	}


	public void setResponsable(String responsable) {
		this.responsable = responsable;
	}
	
	
}
