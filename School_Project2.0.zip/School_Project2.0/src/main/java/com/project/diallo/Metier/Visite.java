package com.project.diallo.Metier;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Visite implements Serializable{
 
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idVisite ;
	private String libelle ;
	private Date date ;
	
	public Visite( String libelle, Date date) {
 
		this.libelle = libelle;
		this.date = date;
	}
	
	public Visite(int idVisite, String libelle, Date date) {
		super();
		this.idVisite = idVisite;
		this.libelle = libelle;
		this.date = date;
	}

	public int getIdVisite() {
		return idVisite;
	}

	public void setIdVisite(int idVisite) {
		this.idVisite = idVisite;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Visite [idVisite=" + idVisite + ", libelle=" + libelle + ", date=" + date + "]";
	}
  
}
